import { useMarqueeIndia } from "./hooks/MarqueeIndia";
import Marquees from "./Marquee";

function App() {
  const { data: indiamarquee } = useMarqueeIndia();

  const [indiamarquee1, indiamarquee2] =
    indiamarquee || [[], []];

  return (
    // 1. Lock to exact screen height and kill scrollbars instantly
    <main className="h-screen w-full overflow-hidden bg-[#07122A]">
      {/* 2. Switch to flex-col so items stack and stretch naturally */}
      <div className="flex flex-col h-full w-full">
        {/* 3. Add flex-1 so this section expands to eat up ALL the empty black space */}
        <section className="flex-1">
          <Marquees
            Country="India"
            value1={indiamarquee1}
            value2={indiamarquee2}
          />
        </section>
      </div>
    </main>
  );
}

export default App;
