import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { API_URL } from "../config.js";

// Helper function to keep things clean
// const transformIndiaData = (apiData) => {
//   if (!Array.isArray(apiData)) return [];
//   return apiData.map((item) => ({
//     name: item["index"] || "--", 
//     value: item["last"] || 0, 
//     change: item["percentChange"] || 0, 
//   }));
// };

// const transformIndiaData = (apiData) => {
//   if (!Array.isArray(apiData)) return [[], []];

//   const transformedData = apiData?.map((item) => ({
//     name: item["index"] || "--",
//     value: item["last"] || 0,
//     change: item["percentChange"] || 0,
//   }));

//   const middleIndex = Math.ceil(transformedData.length / 2);

//   const firstHalf = transformedData.slice(0, middleIndex);
//   const secondHalf = transformedData.slice(middleIndex);

//   return [firstHalf, secondHalf];
// };


const transformIndiaData = (apiData) => {
  // Return an array of 4 empty arrays if the data is invalid to prevent crashes
  if (!Array.isArray(apiData)) return [[], [], [], []];

  // 1. Transform the data
  const transformedData = apiData.map((item) => ({
    name: item["index"] || "--",
    value: item["last"] || 0,
    change: item["percentChange"] || 0,
  }));

  // 2. Determine the size of each quarter
  const chunkSize = Math.ceil(transformedData.length / 4);

  // 3. Split the array into 4 slices
  const q1 = transformedData.slice(0, chunkSize);
  const q2 = transformedData.slice(chunkSize, chunkSize * 2);
  const q3 = transformedData.slice(chunkSize * 2, chunkSize * 3);
  const q4 = transformedData.slice(chunkSize * 3);

  // 4. Return all 4 lists
  return [q1, q2, q3, q4];
};

// 1. The actual API call logic
const fetchLiveData = async () => {
  const response = await axios.get(`${API_URL}/all_indices`);
  const data = response?.data?.data; 
  const [formattedData1, formattedData2, formattedData3, formattedData4] = transformIndiaData(data);
  // Update local storage so we have a fallback for the next session
  localStorage.setItem("marqueeIndia", JSON.stringify([formattedData1, formattedData2, formattedData3, formattedData4]));
  return [formattedData1, formattedData2, formattedData3, formattedData4];
};

// 2. The Custom Hook
export const useMarqueeIndia = () => {
  return useQuery({
    queryKey: ["marqueeIndia"],
    queryFn: fetchLiveData,

    refetchInterval: 30 * 60 * 1000,
    staleTime: 30 * 60 * 1000,
    retry: 3,
    refetchOnMount: "always",

    // Fallback logic for when the component first mounts
    initialData: () => {
      const saved = localStorage.getItem("marqueeIndia");
      try {
        return saved ? JSON.parse(saved) : [[], [], [], []];
      } catch {
        return [[], [], [], []];
      }
    },
  });
};