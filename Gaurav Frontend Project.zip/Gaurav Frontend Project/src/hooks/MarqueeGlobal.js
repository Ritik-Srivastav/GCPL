import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { API_URL } from "../config.js";

const extractPrice = (priceString) => {
  if (!priceString) return 0;

  // 1. Split by space to get "6,616.85"
  const firstPart = priceString?.split(" ")[0];

  // 2. Remove commas so JavaScript can read it as a number
  const cleanNumber = firstPart?.replace(/,/g, "");

  // 3. Convert string to a float
  return parseFloat(cleanNumber);
};


const convertPercentToNumber = (percentStr) => {
  if (!percentStr || typeof percentStr !== "string") return 0;

  // 1. Remove the '%' sign
  // 2. Remove the '+' sign (parseFloat handles '-' automatically, but '+' is optional)
  // 3. Remove any whitespace
  const cleanStr = percentStr?.replace("%", "")?.replace("+", "")?.trim();

  // 4. Convert to number
  const result = parseFloat(cleanStr);

  // 5. Return the number, or 0 if it failed to parse (NaN)
  return isNaN(result) ? 0 : result;
};

// // Helper function to keep things clean
// const transformGlobalData = (apiData) => {
//   if (!Array.isArray(apiData)) return [];
  // return apiData.map((item) => ({
  //   name: item["Name"] || "--",
  //   value: extractPrice(item["Price"] ) || 0,
  //   change: convertPercentToNumber(item["Change %"]) || 0,
  // }));
// };

const transformGlobalData = (apiData) => {
  if (!Array.isArray(apiData)) return [[], []];

  const transformedData = 
    apiData.map((item) => ({
    name: item["Name"] || "--",
    value: extractPrice(item["Price"] ) || 0,
    change: convertPercentToNumber(item["Change %"]) || 0,
  }));

  const middleIndex = Math.ceil(transformedData.length / 2);

  const firstHalf = transformedData.slice(0, middleIndex);
  const secondHalf = transformedData.slice(middleIndex);

  return [firstHalf, secondHalf];
};



// 1. The actual API call logic
const fetchLiveData = async () => {
 
     const response = await axios.get(`${API_URL}/world-indices`);
  const [formattedData1, formattedData2] = transformGlobalData(response?.data);
  // Update local storage so we have a fallback for the next session
  localStorage.setItem("marqueeGlobal", JSON.stringify([formattedData1, formattedData2]));
  return [formattedData1, formattedData2];
 
};

// 2. The Custom Hook
export const useMarqueeGlobal = () => {
  return useQuery({
    queryKey: ["marqueeGlobal"],
    queryFn: fetchLiveData,

    refetchInterval:60 * 60 * 1000,
    staleTime: 60 * 60 * 1000,
    retry: 3,
    refetchOnMount: "always",

    // Fallback logic for when the component first mounts
    initialData: () => {
      const saved = localStorage.getItem("marqueeGlobal");
      try {
        return saved ? JSON.parse(saved) : [[], []];
      } catch {
        return [[], []];
      }
    },
  });
};