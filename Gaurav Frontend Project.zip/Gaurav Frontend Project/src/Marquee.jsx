import Marquee from "react-fast-marquee";
import india from "./images/india.svg";
import global from "./images/global.svg";

const Marquees = ({
  Country = "",
  value1 = [],
  value2 = [],
  value3 = [],
  value4 = [],
}) => {
  const MarqueeComponent = Marquee.default || Marquee;
  const flagSrc = Country?.toLowerCase() === "india" ? india : global;

  // 1. We create a helper function to render the text.
  // Now, if you ever want to change the text size or color, you only change it here once!
  const renderItems = (data) => {
    return data?.map((item, index) => (
      <span key={index}>
        <span className="text-[60px] text-white">{item.name} &nbsp;</span>
        <span
          className={`text-[60px] ${item.value > 0 ? "text-[#69F6B8]" : "text-[#FF0000]"} font-semibold`}
        >
          {item.value} &nbsp;
        </span>
        <span
          className={`text-[60px] ${item.change > 0 ? "text-[#69F6B8]" : "text-[#FF0000]"} font-semibold`}
        >
          ({item.change}%) | &nbsp;
        </span>
      </span>
    ));
  };

  return (
    <div className="flex h-full w-full items-center bg-[#07122A] px-2 py-2 text-white">
      {/* Left Column: Flag and Country */}
      <div className="flex h-16 w-44 shrink-0 items-center gap-3 rounded border border-[#FFFFFF]/10 bg-black/20 px-3">
        <span className="flex size-7 shrink-0 items-center justify-center overflow-hidden rounded-full bg-white/90">
          <img
            src={flagSrc}
            alt={`${Country} flag`}
            className="h-full w-full object-contain"
          />
        </span>
        <span className="truncate whitespace-nowrap text-2xl font-semibold leading-none">
          {Country}
        </span>
      </div>

      {/* Right Column: The Marquees */}
      <div className="ml-4 min-w-0 flex-1 flex flex-col justify-center gap-6">
        {/* 2. We only render the Marquee if the array actually has items in it */}
        {value1?.length > 0 && (
          <MarqueeComponent
            gradient={false}
            speed={250}
            className="py-2"
            autoFill
          >
            {renderItems(value1)}
          </MarqueeComponent>
        )}

        {value2?.length > 0 && (
          <MarqueeComponent
            gradient={false}
            speed={200}
            className="py-2"
            autoFill
          >
            {renderItems(value2)}
          </MarqueeComponent>
        )}

        {value3?.length > 0 && (
          <MarqueeComponent
            gradient={false}
            speed={250}
            className="py-2"
            autoFill
          >
            {renderItems(value3)}
          </MarqueeComponent>
        )}

        {value4?.length > 0 && (
          <MarqueeComponent
            gradient={false}
            speed={200}
            className="py-2"
            autoFill
          >
            {renderItems(value4)}
          </MarqueeComponent>
        )}
      </div>
    </div>
  );
};

export default Marquees;
