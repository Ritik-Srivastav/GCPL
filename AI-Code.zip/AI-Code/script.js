const tickerRows = [
  [
    { region: "IND", flag: "ind", name: "Sensex", value: "73,158.24", delta: "+0.42%", tone: "up" },
    { region: "IND", flag: "ind", name: "Nifty Bank", value: "46,919.80", delta: "-0.12%", tone: "down" },
    { region: "IND", flag: "ind", name: "Nifty IT", value: "37,842.15", delta: "+1.10%", tone: "up" },
    { region: "IND", flag: "ind", name: "Nifty 50", value: "22,124.32", delta: "+0.28%", tone: "up" },
  ],
  [
    { region: "US", flag: "us", name: "S&P 500", value: "73,158.24", delta: "+0.42%", tone: "up" },
    { region: "US", flag: "us", name: "DAX", value: "46,919.80", delta: "-0.12%", tone: "down" },
    { region: "US", flag: "us", name: "FTSE 100", value: "37,842.15", delta: "+1.10%", tone: "up" },
    { region: "US", flag: "us", name: "NASDAQ", value: "18,924.60", delta: "+0.61%", tone: "up" },
  ],
];

const marketCards = [
  {
    kind: "spark",
    title: "NIFTY 100",
    value: "33,123",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    points: [12, 18, 15, 22, 19, 24, 28, 26, 34, 31, 42, 38, 44, 52],
  },
  {
    kind: "spark",
    title: "SENSEX",
    value: "76,015",
    delta: "-2.1%",
    foot: "+300",
    tone: "down",
    points: [52, 48, 50, 44, 42, 40, 38, 41, 36, 34, 35, 31, 29, 24],
  },
  {
    kind: "breadth",
    title: "MARKET BREADTH",
    advancing: "1845",
    declining: "894",
    ratio: "2.12",
  },
  {
    kind: "spark",
    title: "HANG SENG",
    value: "2514",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    points: [8, 10, 12, 15, 14, 18, 19, 22, 24, 25, 30, 33, 36, 42],
  },
  {
    kind: "callout",
    title: "TOP GAINER",
    value: "Nifty Metal",
    delta: "+3.4%",
    tone: "up",
    illustration: "bull",
  },
  {
    kind: "callout",
    title: "TOP LOSER",
    value: "Nifty IT",
    delta: "-4.7%",
    tone: "down",
    illustration: "bear",
  },
  {
    kind: "stat",
    title: "NEW 52W HIGH",
    value: "124",
    subtitle: "stocks",
    tone: "up",
    illustration: "barsUp",
  },
  {
    kind: "stat",
    title: "NEW 52W LOW",
    value: "23",
    subtitle: "stocks",
    tone: "down",
    illustration: "barsDown",
  },
];

const economicCards = [
  {
    kind: "stat",
    title: "REAL GDP GROWTH",
    value: "6.7%",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    illustration: "gdp",
    classes: "col-span-2 min-[500px]:col-span-1 min-[500px]:row-span-2",
  },
  {
    kind: "stat",
    title: "GROSS GST REVENUE",
    value: "₹ 3.8 L Cr",
    delta: "+0.2%",
    tone: "up",
    illustration: "coinsUp",
    classes: "col-span-2 min-[500px]:col-span-1 min-[500px]:row-span-2",
  },
  {
    kind: "stat",
    title: "FISCAL DEFICIT",
    value: "3.5%",
    delta: "+0.2%",
    tone: "up",
    illustration: "piggy",
    classes: "col-span-2 min-[500px]:col-span-1 min-[500px]:row-span-2",
  },
  {
    kind: "spark",
    title: "CORE INFLATION",
    value: "3.4%",
    subtitle: "Monetary policy stance",
    tone: "up",
    points: [9, 12, 16, 18, 17, 20, 24, 22, 28, 26, 31, 38, 42, 47],
    compact: true,
  },
  {
    kind: "spark",
    title: "10Y G-SEC YIELD",
    value: "-7.12%",
    tone: "down",
    points: [48, 46, 45, 44, 39, 37, 35, 36, 31, 28, 24, 27, 23, 18],
    compact: true,
  },
];

const commodityCards = [
  {
    kind: "spark",
    title: "USD VS INR",
    value: "83.50",
    delta: "-0.12",
    foot: "-0.13",
    tone: "down",
    flag: "us",
    classes: "col-span-2 min-[500px]:col-span-1 min-[500px]:row-span-2",
    points: [34, 31, 26, 27, 23, 21, 24, 19, 25, 22, 17, 20, 18, 14],
  },
  {
    kind: "spark",
    title: "EU VS INR",
    value: "89.50",
    delta: "-3.1",
    tone: "down",
    flag: "eu",
    compact: true,
    points: [28, 29, 26, 24, 25, 22, 20, 18, 23, 21, 17, 15, 19, 12],
  },
  {
    kind: "stat",
    title: "CRUDE OIL",
    value: "$118",
    tone: "neutral",
    illustration: "barrel",
  },
  {
    kind: "stat",
    title: "GOLD",
    value: "8.71",
    delta: "+2.1%",
    tone: "gold",
    illustration: "gold",
  },
  {
    kind: "spark",
    title: "GBP VS INR",
    value: "108.2",
    delta: "-2.1",
    tone: "down",
    flag: "uk",
    compact: true,
    points: [32, 31, 29, 30, 28, 27, 24, 23, 22, 20, 18, 19, 17, 16],
  },
  {
    kind: "stat",
    title: "COPPER",
    value: "$5.67",
    tone: "copper",
    illustration: "copper",
  },
  {
    kind: "stat",
    title: "SILVER",
    value: "2.56",
    delta: "-1.4",
    tone: "silver",
    illustration: "silver",
  },
];

const CARD_BASE =
  "metric-card group relative flex h-full min-w-0 flex-col overflow-hidden rounded-[18px] border border-white/10 p-3 shadow-card backdrop-blur-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-400/35";

let sparklineCounter = 0;

function flagIcon(flag) {
  const flags = {
    ind: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#fff"/>
        <rect width="64" height="21.33" fill="#ff8d31"/>
        <rect y="42.67" width="64" height="21.33" fill="#17934e"/>
        <circle cx="32" cy="32" r="7.6" fill="none" stroke="#203ea9" stroke-width="2.6"/>
        <circle cx="32" cy="32" r="1.9" fill="#203ea9"/>
      </svg>
    `,
    us: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#fff"/>
        <rect width="64" height="7" y="0" fill="#d84b52"/>
        <rect width="64" height="7" y="14" fill="#d84b52"/>
        <rect width="64" height="7" y="28" fill="#d84b52"/>
        <rect width="64" height="7" y="42" fill="#d84b52"/>
        <rect width="64" height="7" y="56" fill="#d84b52"/>
        <rect width="29" height="30" fill="#3151c4"/>
        <circle cx="9" cy="9" r="1.5" fill="#fff"/>
        <circle cx="16" cy="14" r="1.5" fill="#fff"/>
        <circle cx="22" cy="9" r="1.5" fill="#fff"/>
        <circle cx="10" cy="20" r="1.5" fill="#fff"/>
        <circle cx="18" cy="24" r="1.5" fill="#fff"/>
        <circle cx="24" cy="18" r="1.5" fill="#fff"/>
      </svg>
    `,
    eu: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#1748c9"/>
        <g fill="#f4c739">
          <circle cx="32" cy="11" r="2.2"/>
          <circle cx="42.5" cy="14.5" r="2.2"/>
          <circle cx="49.8" cy="22" r="2.2"/>
          <circle cx="53" cy="32" r="2.2"/>
          <circle cx="49.8" cy="42" r="2.2"/>
          <circle cx="42.5" cy="49.5" r="2.2"/>
          <circle cx="32" cy="53" r="2.2"/>
          <circle cx="21.5" cy="49.5" r="2.2"/>
          <circle cx="14.2" cy="42" r="2.2"/>
          <circle cx="11" cy="32" r="2.2"/>
          <circle cx="14.2" cy="22" r="2.2"/>
          <circle cx="21.5" cy="14.5" r="2.2"/>
        </g>
      </svg>
    `,
    uk: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#2345aa"/>
        <path d="M0 8 8 0l56 56-8 8Z" fill="#fff"/>
        <path d="M56 0 64 8 8 64 0 56Z" fill="#fff"/>
        <path d="M0 14 14 0l50 50-14 14Z" fill="#d7444e"/>
        <path d="M50 0 64 14 14 64 0 50Z" fill="#d7444e"/>
        <rect x="25" width="14" height="64" fill="#fff"/>
        <rect y="25" width="64" height="14" fill="#fff"/>
        <rect x="28" width="8" height="64" fill="#d7444e"/>
        <rect y="28" width="64" height="8" fill="#d7444e"/>
      </svg>
    `,
  };

  return flags[flag] || "";
}

function flagMarkup(flag, size = "sm") {
  if (!flag) return "";

  const dimensions = size === "xs" ? "h-4 w-4" : "h-6 w-6";
  return `
    <span class="${dimensions} inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full shadow-[0_5px_10px_rgba(0,0,0,0.35)] ring-1 ring-white/10">
      ${flagIcon(flag)}
    </span>
  `;
}

function toneBackground(tone, kind = "default") {
  if (kind === "callout" && tone === "up") {
    return "metric-card--up bg-[linear-gradient(180deg,rgba(6,111,56,0.96),rgba(4,67,39,0.98))]";
  }

  if (kind === "callout" && tone === "down") {
    return "metric-card--down bg-[linear-gradient(180deg,rgba(113,27,35,0.96),rgba(61,13,22,0.98))]";
  }

  if (tone === "down") {
    return "metric-card--down bg-[radial-gradient(circle_at_82%_82%,rgba(255,40,49,0.12),transparent_24%),linear-gradient(180deg,rgba(17,39,61,0.96),rgba(24,14,23,0.98))]";
  }

  if (tone === "gold") {
    return "metric-card--gold bg-[radial-gradient(circle_at_82%_82%,rgba(255,216,79,0.12),transparent_24%),linear-gradient(180deg,rgba(68,57,18,0.98),rgba(38,31,8,0.98))]";
  }

  if (tone === "copper") {
    return "metric-card--copper bg-[radial-gradient(circle_at_82%_82%,rgba(230,154,99,0.13),transparent_24%),linear-gradient(180deg,rgba(63,40,26,0.98),rgba(39,23,13,0.98))]";
  }

  if (tone === "silver") {
    return "metric-card--silver bg-[radial-gradient(circle_at_82%_82%,rgba(235,240,247,0.12),transparent_24%),linear-gradient(180deg,rgba(47,51,62,0.98),rgba(30,33,42,0.98))]";
  }

  if (tone === "neutral") {
    return "bg-[radial-gradient(circle_at_82%_82%,rgba(219,224,232,0.08),transparent_24%),linear-gradient(180deg,rgba(24,24,29,0.98),rgba(8,10,15,0.98))]";
  }

  return "metric-card--up bg-[radial-gradient(circle_at_82%_82%,rgba(21,240,168,0.08),transparent_24%),linear-gradient(180deg,rgba(17,39,61,0.96),rgba(8,18,32,0.98))]";
}

function deltaClass(tone) {
  return tone === "down" ? "text-red-400" : "text-emerald-300";
}

function deltaArrow(tone) {
  return tone === "down" ? "▼" : "▲";
}

function cardValueClass(card) {
  if (card.kind === "callout") {
    return "max-w-[calc(100%-4.9rem)] text-[1.5rem] leading-[1.02] tracking-[-0.03em]";
  }

  if (card.compact || card.value.length > 7) {
    return "text-[1.8rem] min-[500px]:text-[2.05rem]";
  }

  return "text-[1.95rem] min-[500px]:text-[2.28rem]";
}

function sparkline(points, tone) {
  const width = 220;
  const height = 82;
  const padding = 6;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const scale = max - min || 1;
  const color = tone === "down" ? "#ff2831" : "#15f0a8";

  const mappedPairs = points.map((point, index) => {
    const x = padding + (index * (width - padding * 2)) / (points.length - 1);
    const y = height - padding - ((point - min) * (height - padding * 2)) / scale;
    return [x, y];
  });

  const mapped = mappedPairs.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const [endX, endY] = mappedPairs[mappedPairs.length - 1];
  const area = `${mapped} ${width - padding},${height - padding} ${padding},${height - padding}`;
  const gradientId = `area-${tone}-${sparklineCounter++}`;

  return `
    <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true" class="h-full w-full overflow-visible">
      <defs>
        <linearGradient id="${gradientId}" x1="0%" x2="100%" y1="0%" y2="100%">
          <stop offset="0%" stop-color="${color}" stop-opacity="0.45"></stop>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"></stop>
        </linearGradient>
      </defs>
      <polyline class="sparkline-area" points="${area}" fill="url(#${gradientId})"></polyline>
      <polyline class="sparkline-line" points="${mapped}" style="color:${color}; stroke:${color};" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></polyline>
      <circle class="sparkline-end" cx="${endX.toFixed(1)}" cy="${endY.toFixed(1)}" r="4.6" fill="${color}" opacity="0.96"></circle>
    </svg>
  `;
}

function icon(name) {
  const icons = {
    bull: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <path d="M28 65c6-19 16-31 31-37l7 8 15-17 17 15-8 3c5 10 9 20 8 31-9 4-20 5-33 4l2-9-13 4-10-3-5 7H28Z" fill="#d9ddd9"/>
        <path d="M28 66c8-3 18-4 30-4 12 0 24-1 34-4" stroke="#6b7e7e" stroke-width="2.8" stroke-linecap="round"/>
        <path d="M82 34c6 6 11 16 16 31" stroke="#1fdf89" stroke-width="6" stroke-linecap="round"/>
        <path d="m92 18 18 1-1 18" stroke="#23f29d" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `,
    bear: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <path d="M93 63c-12 7-28 9-44 7l-7-10-8 3c-6-5-10-12-10-20 0-8 3-14 9-19l11 4 5-11c18 1 33 10 43 22 8 10 9 18 1 24Z" fill="#d9d5da"/>
        <path d="M30 19C22 28 15 37 12 49" stroke="#ff6a82" stroke-width="7" stroke-linecap="round"/>
        <path d="m16 17-12 3 3 12" stroke="#ff6a82" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M45 70c17 2 32 0 46-6" stroke="#7c6b6d" stroke-width="2.8" stroke-linecap="round"/>
      </svg>
    `,
    barsUp: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="18" y="44" width="16" height="28" rx="4" fill="#27db93"/>
        <rect x="42" y="34" width="16" height="38" rx="4" fill="#20c181"/>
        <rect x="66" y="21" width="16" height="51" rx="4" fill="#169a68"/>
        <path d="M21 27c18 4 32-2 49-19" stroke="#42ffb9" stroke-width="7" stroke-linecap="round"/>
        <path d="m72 8 17 0-1 17" stroke="#42ffb9" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `,
    barsDown: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="18" y="42" width="16" height="30" rx="4" fill="#ff6a6f"/>
        <rect x="42" y="33" width="16" height="39" rx="4" fill="#f34e54"/>
        <rect x="66" y="24" width="16" height="48" rx="4" fill="#e33f45"/>
        <path d="M20 13c20 0 36 8 53 24" stroke="#ff7b86" stroke-width="7" stroke-linecap="round"/>
        <path d="m72 42 2-16 16 2" stroke="#ff7b86" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `,
    gdp: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="19" y="43" width="18" height="29" rx="4" fill="#c28746"/>
        <rect x="44" y="29" width="18" height="43" rx="4" fill="#d49a58"/>
        <rect x="69" y="13" width="18" height="59" rx="4" fill="#e4b77d"/>
        <text x="26" y="59" fill="#2c1907" font-size="20" font-family="Arial" font-weight="700">G</text>
        <text x="50" y="45" fill="#2c1907" font-size="20" font-family="Arial" font-weight="700">D</text>
        <text x="75" y="29" fill="#2c1907" font-size="20" font-family="Arial" font-weight="700">P</text>
      </svg>
    `,
    coinsUp: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <path d="M18 64 52 39l3 11 36-35" stroke="#78d66d" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="m81 15 18-3-3 18" stroke="#78d66d" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        <ellipse cx="28" cy="71" rx="12" ry="5" fill="#ca9a43"/>
        <ellipse cx="50" cy="63" rx="12" ry="5" fill="#d9ab45"/>
        <ellipse cx="72" cy="55" rx="12" ry="5" fill="#e6bb4b"/>
        <ellipse cx="92" cy="46" rx="12" ry="5" fill="#f1cb5c"/>
        <rect x="16" y="58" width="24" height="13" rx="6" fill="#ca9a43"/>
        <rect x="38" y="50" width="24" height="13" rx="6" fill="#d9ab45"/>
        <rect x="60" y="42" width="24" height="13" rx="6" fill="#e6bb4b"/>
        <rect x="80" y="33" width="24" height="13" rx="6" fill="#f1cb5c"/>
      </svg>
    `,
    piggy: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <ellipse cx="58" cy="47" rx="28" ry="23" fill="#f0ece8"/>
        <circle cx="87" cy="44" r="9" fill="#e7e2dc"/>
        <circle cx="37" cy="32" r="8" fill="#f8f4f0"/>
        <circle cx="51" cy="48" r="3" fill="#1b1d24"/>
        <path d="M48 24c7-8 16-11 29-11" stroke="#ddd7d0" stroke-width="5" stroke-linecap="round"/>
        <path d="M28 66h14M72 69h14" stroke="#d8d1ca" stroke-width="8" stroke-linecap="round"/>
        <path d="M22 72h76" stroke="#be9560" stroke-width="5" stroke-linecap="round" opacity=".45"/>
        <circle cx="18" cy="74" r="7" fill="#b46e2b"/>
        <circle cx="31" cy="74" r="7" fill="#c78536"/>
        <circle cx="44" cy="74" r="7" fill="#da9b42"/>
        <circle cx="96" cy="74" r="7" fill="#da9b42"/>
      </svg>
    `,
    barrel: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="44" y="18" width="34" height="50" rx="7" fill="#44484f"/>
        <path d="M44 28h34M44 44h34M44 60h34" stroke="#9a9ea5" stroke-width="5"/>
        <ellipse cx="61" cy="17" rx="17" ry="5" fill="#62666d"/>
        <ellipse cx="61" cy="68" rx="17" ry="5" fill="#26292f"/>
        <path d="M64 31c-6 3-9 10-6 16 3 6 10 8 16 5-3 5-9 8-15 8-10 0-17-8-17-17s7-17 17-17c2 0 4 0 5 1Z" fill="#1a1c20"/>
      </svg>
    `,
    gold: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <path d="m28 54 18-15 20 9-18 15-20-9Z" fill="#ffd84f"/>
        <path d="m48 63 18-15 24 10-18 15-24-10Z" fill="#f2bf34"/>
        <path d="m28 54 20 9v9l-20-9v-9Zm38-6 24 10v9L66 58v-10Z" fill="#d69e14"/>
        <path d="m47 39 20 9 15-12-20-8-15 11Z" fill="#ffe587"/>
      </svg>
    `,
    copper: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="24" y="44" width="42" height="14" rx="5" fill="#cc8657"/>
        <rect x="40" y="28" width="42" height="14" rx="5" fill="#e3a173"/>
        <rect x="56" y="44" width="42" height="14" rx="5" fill="#b96e3e"/>
        <rect x="48" y="58" width="42" height="14" rx="5" fill="#db9a6e"/>
      </svg>
    `,
    silver: `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <path d="m28 58 21-17 18 8-21 18-18-9Z" fill="#eef2f8"/>
        <path d="m52 50 21-17 19 8-21 18-19-9Z" fill="#d0d8e0"/>
        <path d="m46 67 21-18 17 7-21 18-17-7Z" fill="#f7fafc"/>
      </svg>
    `,
  };

  return icons[name] || "";
}

function mountTickers() {
  const root = document.getElementById("ticker-board");
  root.innerHTML = tickerRows
    .map(
      (row) => `
        <div class="grid grid-cols-4 gap-px">
          ${row
            .map(
              (item) => `
                <article class="min-w-0 bg-[radial-gradient(circle_at_50%_0%,rgba(64,99,188,0.11),transparent_52%),linear-gradient(180deg,rgba(12,25,48,0.98),rgba(7,15,27,0.98))] px-2 py-2 min-[500px]:px-2.5">
                  <div class="flex min-w-0 items-center gap-1.5 text-[8px] uppercase tracking-[0.08em] text-slate-200 min-[500px]:text-[9px]">
                    ${flagMarkup(item.flag, "xs")}
                    <span class="rounded-full border border-white/10 ${item.flag === "us" ? "bg-blue-500/20 text-blue-50" : "bg-amber-300/15 text-amber-50"} px-1.5 py-0.5">${item.region}</span>
                    <span class="truncate font-medium tracking-[0.02em] text-slate-100">${item.name}</span>
                  </div>
                  <div class="mt-1.5 flex items-baseline justify-between gap-2 text-[11px] min-[500px]:text-[12px]">
                    <span class="js-ticker-value whitespace-nowrap text-slate-300">${item.value}</span>
                    <span class="js-ticker-delta whitespace-nowrap font-semibold ${item.tone === "down" ? "text-red-400" : "text-emerald-300"}">${item.delta}</span>
                  </div>
                </article>
              `,
            )
            .join("")}
        </div>
      `,
    )
    .join("");
}

function renderMeta(card) {
  if (!card.delta && !card.foot) {
    return "";
  }

  const tone = card.tone === "down" ? "down" : "up";

  return `
    <div class="relative z-10 mt-2 inline-flex w-fit items-center gap-2 rounded-md bg-slate-400/10 px-2 py-1 text-[11px] font-semibold text-slate-50 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
      ${
        card.delta
          ? `<span class="${deltaClass(tone)} inline-flex items-center gap-1"><span class="text-[9px]">${deltaArrow(tone)}</span>${card.delta}</span>`
          : ""
      }
      ${card.foot ? `<span class="text-white/85">${card.foot}</span>` : ""}
    </div>
  `;
}

function renderSparkCard(card) {
  const tone = card.tone === "down" ? "down" : "up";
  const flag = flagMarkup(card.flag);
  const sparkClass = card.compact ? "h-12 pt-2" : "h-16 pt-2";
  const valueClass = cardValueClass(card);

  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone)} ${card.classes || ""}">
      <div class="relative z-10 flex items-center gap-2">
        ${flag}
        <span class="text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</span>
      </div>
      <div class="relative z-10 mt-1 whitespace-nowrap font-display font-semibold leading-[0.92] tracking-[-0.06em] text-white ${valueClass}">${card.value}</div>
      ${card.subtitle ? `<div class="relative z-10 mt-1 text-[10px] leading-[1.25] text-slate-400">${card.subtitle}</div>` : ""}
      ${renderMeta(card)}
      <div class="relative z-10 mt-auto ${sparkClass}">${sparkline(card.points, tone)}</div>
    </article>
  `;
}

function renderBreadthCard(card) {
  return `
    <article class="${CARD_BASE} ${toneBackground("up")}">
      <div class="relative z-10 text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</div>
      <div class="relative z-10 mt-2 grid grid-cols-2 gap-x-2 gap-y-1">
        <div class="min-w-0">
          <div class="text-[2rem] font-semibold leading-[0.9] tracking-[-0.06em] text-emerald-300">${card.advancing}</div>
          <div class="mt-0.5 text-[11px] text-slate-200">Advancing</div>
        </div>
        <div class="min-w-0 text-right">
          <div class="text-[2rem] font-semibold leading-[0.9] tracking-[-0.06em] text-red-400">${card.declining}</div>
          <div class="mt-0.5 text-[11px] text-slate-200">Declining</div>
        </div>
        <div class="col-span-2 mt-1 h-2 overflow-hidden rounded-full bg-[linear-gradient(90deg,rgba(34,235,163,0.26),rgba(255,40,49,0.22))]">
          <div class="h-full w-[67%] bg-[linear-gradient(90deg,rgba(30,215,160,0.96),rgba(64,247,187,0.68))]"></div>
        </div>
        <div class="col-span-2 mt-1 flex items-center justify-between text-[11px] font-medium text-slate-50">
          <span>A/D Ratio</span>
          <strong>${card.ratio}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderCalloutCard(card) {
  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone, "callout")} ${card.classes || ""}">
      <div class="relative z-10 text-[11px] font-medium uppercase tracking-[0.02em] text-slate-200">${card.title}</div>
      <div class="relative z-10 mt-1 font-display font-semibold text-white ${cardValueClass(card)}">${card.value}</div>
      ${renderMeta(card)}
      <div class="absolute bottom-0 right-0 z-10 h-[4.7rem] w-[6rem] opacity-[0.98] drop-shadow-[0_12px_18px_rgba(0,0,0,0.35)]">
        ${icon(card.illustration)}
      </div>
    </article>
  `;
}

function renderStatCard(card) {
  const flag = flagMarkup(card.flag);
  const valueClass = cardValueClass(card);

  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone)} ${card.classes || ""}">
      <div class="relative z-10 flex items-center gap-2">
        ${flag}
        <span class="text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</span>
      </div>
      <div class="relative z-10 mt-1 whitespace-nowrap font-display font-semibold leading-[0.92] tracking-[-0.06em] text-white ${valueClass}">${card.value}</div>
      ${card.subtitle ? `<div class="relative z-10 mt-1 text-[10px] leading-[1.25] text-slate-400">${card.subtitle}</div>` : ""}
      ${renderMeta(card)}
      ${
        card.illustration
          ? `<div class="absolute bottom-0 right-0 z-10 h-[4.5rem] w-[5.8rem] opacity-[0.98] drop-shadow-[0_12px_18px_rgba(0,0,0,0.35)]">${icon(card.illustration)}</div>`
          : ""
      }
    </article>
  `;
}

function renderCards(cards, rootId) {
  const root = document.getElementById(rootId);
  root.innerHTML = cards
    .map((card) => {
      if (card.kind === "spark") return renderSparkCard(card);
      if (card.kind === "breadth") return renderBreadthCard(card);
      if (card.kind === "callout") return renderCalloutCard(card);
      return renderStatCard(card);
    })
    .join("");
}

function animateTickers() {
  const tickerValues = [...document.querySelectorAll(".js-ticker-value")];
  const tickerDeltas = [...document.querySelectorAll(".js-ticker-delta")];

  window.setInterval(() => {
    tickerValues.forEach((node, index) => {
      const raw = Number(node.textContent.replace(/,/g, ""));
      const drift = (Math.random() - 0.5) * (index % 2 === 0 ? 18 : 32);
      const next = Math.max(raw + drift, 1000);
      node.textContent = next.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    });

    tickerDeltas.forEach((node) => {
      const positive = Math.random() > 0.33;
      const delta = (Math.random() * 1.5 + 0.05).toFixed(2);
      node.textContent = `${positive ? "+" : "-"}${delta}%`;
      node.classList.toggle("text-emerald-300", positive);
      node.classList.toggle("text-red-400", !positive);
    });
  }, 3200);
}

mountTickers();
renderCards(marketCards, "market-grid");
renderCards(economicCards, "economic-grid");
renderCards(commodityCards, "commodity-grid");
animateTickers();
