const tickerRows = [
  [
    { region: "IND", flag: "ind", name: "Sensex", value: "73,158.24", delta: "+0.42%", tone: "up" },
    { region: "IND", flag: "ind", name: "Nifty Bank", value: "46,919.80", delta: "-0.12%", tone: "down" },
    { region: "IND", flag: "ind", name: "Nifty IT", value: "37,842.15", delta: "+1.10%", tone: "up" },
    { region: "IND", flag: "ind", name: "Nifty 50", value: "22,124.32", delta: "+0.28%", tone: "up" },
  ],
  [
    { region: "US", flag: "us", name: "S&P 500", value: "73,158.24", delta: "+0.42%", tone: "up" },
    { region: "US", flag: "us", name: "DAX", value: "46,919.80", delta: "-0.12%", tone: "down" },
    { region: "US", flag: "us", name: "FTSE 100", value: "37,842.15", delta: "+1.10%", tone: "up" },
    { region: "US", flag: "us", name: "NASDAQ", value: "18,924.60", delta: "+0.61%", tone: "up" },
  ],
];

const marketCards = [
  {
    kind: "spark",
    title: "NIFTY 100",
    value: "33,123",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    points: [12, 18, 15, 22, 19, 24, 28, 26, 34, 31, 42, 38, 44, 52],
  },
  {
    kind: "spark",
    title: "SENSEX",
    value: "76,015",
    delta: "-2.1%",
    foot: "+300",
    tone: "down",
    points: [52, 48, 50, 44, 42, 40, 38, 41, 36, 34, 35, 31, 29, 24],
  },
  {
    kind: "breadth",
    title: "MARKET BREADTH",
    advancing: "1845",
    declining: "894",
    ratio: "2.12",
  },
  {
    kind: "spark",
    title: "HANG SENG",
    value: "2514",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    points: [8, 10, 12, 15, 14, 18, 19, 22, 24, 25, 30, 33, 36, 42],
  },
  {
    kind: "callout",
    title: "TOP GAINER",
    value: "Nifty Metal",
    delta: "+3.4%",
    tone: "up",
    illustration: "bull",
    mediaWrapClass: "bottom-[-0.15rem] right-[-0.15rem] h-[5.2rem] w-[5.6rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "callout",
    title: "TOP LOSER",
    value: "Nifty IT",
    delta: "-4.7%",
    tone: "down",
    illustration: "bear",
    mediaWrapClass: "bottom-[-0.2rem] right-[-0.15rem] h-[5.05rem] w-[5.45rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "NEW 52W HIGH",
    value: "124",
    subtitle: "stocks",
    tone: "up",
    illustration: "barsUp",
    mediaWrapClass: "bottom-1 right-1 h-[3.35rem] w-[3.45rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "NEW 52W LOW",
    value: "23",
    subtitle: "stocks",
    tone: "down",
    illustration: "barsDown",
    mediaWrapClass: "bottom-1 right-1 h-[3.35rem] w-[3.45rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
];

const economicCards = [
  {
    kind: "stat",
    title: "REAL GDP GROWTH",
    value: "6.7%",
    delta: "+0.4%",
    foot: "+300",
    tone: "up",
    illustration: "gdp",
    classes: "col-span-1 min-[390px]:col-span-2 md:col-span-1 md:row-span-2",
    mediaWrapClass: "bottom-1 right-0 h-[4.9rem] w-[6.1rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "GROSS GST REVENUE",
    value: "₹ 3.8 L Cr",
    delta: "+0.2%",
    tone: "up",
    illustration: "coinsUp",
    classes: "col-span-1 min-[390px]:col-span-2 md:col-span-1 md:row-span-2",
    mediaWrapClass: "bottom-1 right-0 h-[5.05rem] w-[5.9rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "FISCAL DEFICIT",
    value: "3.5%",
    delta: "+0.2%",
    tone: "up",
    illustration: "piggy",
    classes: "col-span-1 min-[390px]:col-span-2 md:col-span-1 md:row-span-2",
    mediaWrapClass: "bottom-1 right-[-0.1rem] h-[5rem] w-[6rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "spark",
    title: "CORE INFLATION",
    value: "3.4%",
    subtitle: "Monetary policy stance",
    tone: "up",
    points: [9, 12, 16, 18, 17, 20, 24, 22, 28, 26, 31, 38, 42, 47],
    compact: true,
  },
  {
    kind: "spark",
    title: "10Y G-SEC YIELD",
    value: "-7.12%",
    tone: "down",
    points: [48, 46, 45, 44, 39, 37, 35, 36, 31, 28, 24, 27, 23, 18],
    compact: true,
  },
];

const commodityCards = [
  {
    kind: "spark",
    title: "USD VS INR",
    value: "83.50",
    delta: "-0.12",
    foot: "-0.13",
    tone: "down",
    flag: "us",
    classes: "col-span-1 min-[390px]:col-span-2 md:col-span-1 md:row-span-2",
    points: [34, 31, 26, 27, 23, 21, 24, 19, 25, 22, 17, 20, 18, 14],
  },
  {
    kind: "spark",
    title: "EU VS INR",
    value: "89.50",
    delta: "-3.1",
    tone: "down",
    flag: "eu",
    compact: true,
    points: [28, 29, 26, 24, 25, 22, 20, 18, 23, 21, 17, 15, 19, 12],
  },
  {
    kind: "stat",
    title: "CRUDE OIL",
    value: "$118",
    tone: "neutral",
    illustration: "barrel",
    mediaWrapClass: "bottom-1 right-1 h-[3.85rem] w-[4.25rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "GOLD",
    value: "8.71",
    delta: "+2.1%",
    tone: "gold",
    illustration: "gold",
    mediaWrapClass: "bottom-1 right-1 h-[3.1rem] w-[3.45rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "spark",
    title: "GBP VS INR",
    value: "108.2",
    delta: "-2.1",
    tone: "down",
    flag: "uk",
    compact: true,
    points: [32, 31, 29, 30, 28, 27, 24, 23, 22, 20, 18, 19, 17, 16],
  },
  {
    kind: "stat",
    title: "COPPER",
    value: "$5.67",
    tone: "copper",
    illustration: "copper",
    mediaWrapClass: "bottom-1 right-1 h-[2.7rem] w-[4rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
  {
    kind: "stat",
    title: "SILVER",
    value: "2.56",
    delta: "-1.4",
    tone: "silver",
    illustration: "silver",
    mediaWrapClass: "bottom-1 right-1 h-[3rem] w-[4.1rem]",
    mediaClass: "h-full w-full object-contain object-bottom-right",
  },
];

const CARD_BASE =
  "metric-card group relative flex h-full min-w-0 flex-col overflow-hidden rounded-[18px] border border-white/10 p-3 shadow-card backdrop-blur-sm transition duration-300 hover:-translate-y-0.5 hover:border-sky-400/35";

let sparklineCounter = 0;

const IMAGE_ASSETS = {
  bull: "./images and icons/bull.png",
  bear: "./images and icons/bear.png",
  gdp: "./images and icons/gdp growth.png",
  coinsUp: "./images and icons/gross gst.png",
  piggy: "./images and icons/fiscal deficit.png",
  barrel: "./images and icons/crude oil.png",
  gold: "./images and icons/gold.png",
  silver: "./images and icons/silver.png",
  barsUp: "./images and icons/52 week high.png",
  barsDown: "./images and icons/52 week low.png",
  india: "./images and icons/india.png",
  global: "./images and icons/global.png",
};

function flagIcon(flag) {
  const flags = {
    ind: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#fff"/>
        <rect width="64" height="21.33" fill="#ff8d31"/>
        <rect y="42.67" width="64" height="21.33" fill="#17934e"/>
        <circle cx="32" cy="32" r="7.6" fill="none" stroke="#203ea9" stroke-width="2.6"/>
        <circle cx="32" cy="32" r="1.9" fill="#203ea9"/>
      </svg>
    `,
    us: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#fff"/>
        <rect width="64" height="7" y="0" fill="#d84b52"/>
        <rect width="64" height="7" y="14" fill="#d84b52"/>
        <rect width="64" height="7" y="28" fill="#d84b52"/>
        <rect width="64" height="7" y="42" fill="#d84b52"/>
        <rect width="64" height="7" y="56" fill="#d84b52"/>
        <rect width="29" height="30" fill="#3151c4"/>
        <circle cx="9" cy="9" r="1.5" fill="#fff"/>
        <circle cx="16" cy="14" r="1.5" fill="#fff"/>
        <circle cx="22" cy="9" r="1.5" fill="#fff"/>
        <circle cx="10" cy="20" r="1.5" fill="#fff"/>
        <circle cx="18" cy="24" r="1.5" fill="#fff"/>
        <circle cx="24" cy="18" r="1.5" fill="#fff"/>
      </svg>
    `,
    eu: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#1748c9"/>
        <g fill="#f4c739">
          <circle cx="32" cy="11" r="2.2"/>
          <circle cx="42.5" cy="14.5" r="2.2"/>
          <circle cx="49.8" cy="22" r="2.2"/>
          <circle cx="53" cy="32" r="2.2"/>
          <circle cx="49.8" cy="42" r="2.2"/>
          <circle cx="42.5" cy="49.5" r="2.2"/>
          <circle cx="32" cy="53" r="2.2"/>
          <circle cx="21.5" cy="49.5" r="2.2"/>
          <circle cx="14.2" cy="42" r="2.2"/>
          <circle cx="11" cy="32" r="2.2"/>
          <circle cx="14.2" cy="22" r="2.2"/>
          <circle cx="21.5" cy="14.5" r="2.2"/>
        </g>
      </svg>
    `,
    uk: `
      <svg viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" fill="#2345aa"/>
        <path d="M0 8 8 0l56 56-8 8Z" fill="#fff"/>
        <path d="M56 0 64 8 8 64 0 56Z" fill="#fff"/>
        <path d="M0 14 14 0l50 50-14 14Z" fill="#d7444e"/>
        <path d="M50 0 64 14 14 64 0 50Z" fill="#d7444e"/>
        <rect x="25" width="14" height="64" fill="#fff"/>
        <rect y="25" width="64" height="14" fill="#fff"/>
        <rect x="28" width="8" height="64" fill="#d7444e"/>
        <rect y="28" width="64" height="8" fill="#d7444e"/>
      </svg>
    `,
  };

  return flags[flag] || "";
}

function flagMarkup(flag, size = "sm") {
  if (!flag) return "";

  const dimensions = size === "xs" ? "h-4 w-4" : "h-6 w-6";
  return `
    <span class="${dimensions} inline-flex shrink-0 items-center justify-center overflow-hidden rounded-full shadow-[0_5px_10px_rgba(0,0,0,0.35)] ring-1 ring-white/10">
      ${flagIcon(flag)}
    </span>
  `;
}

function regionIcon(region) {
  const iconSrc = region === "IND" ? IMAGE_ASSETS.india : IMAGE_ASSETS.global;
  return `<img src="${iconSrc}" alt="" class="h-4 w-4 shrink-0 object-contain ${region === "IND" ? "rounded-full" : ""}" loading="eager" decoding="async">`;
}

function toneBackground(tone, kind = "default") {
  if (kind === "callout" && tone === "up") {
    return "metric-card--up bg-[linear-gradient(180deg,rgba(6,111,56,0.96),rgba(4,67,39,0.98))]";
  }

  if (kind === "callout" && tone === "down") {
    return "metric-card--down bg-[linear-gradient(180deg,rgba(113,27,35,0.96),rgba(61,13,22,0.98))]";
  }

  if (tone === "down") {
    return "metric-card--down bg-[radial-gradient(circle_at_82%_82%,rgba(255,40,49,0.12),transparent_24%),linear-gradient(180deg,rgba(17,39,61,0.96),rgba(24,14,23,0.98))]";
  }

  if (tone === "gold") {
    return "metric-card--gold bg-[radial-gradient(circle_at_82%_82%,rgba(255,216,79,0.12),transparent_24%),linear-gradient(180deg,rgba(68,57,18,0.98),rgba(38,31,8,0.98))]";
  }

  if (tone === "copper") {
    return "metric-card--copper bg-[radial-gradient(circle_at_82%_82%,rgba(230,154,99,0.13),transparent_24%),linear-gradient(180deg,rgba(63,40,26,0.98),rgba(39,23,13,0.98))]";
  }

  if (tone === "silver") {
    return "metric-card--silver bg-[radial-gradient(circle_at_82%_82%,rgba(235,240,247,0.12),transparent_24%),linear-gradient(180deg,rgba(47,51,62,0.98),rgba(30,33,42,0.98))]";
  }

  if (tone === "neutral") {
    return "bg-[radial-gradient(circle_at_82%_82%,rgba(219,224,232,0.08),transparent_24%),linear-gradient(180deg,rgba(24,24,29,0.98),rgba(8,10,15,0.98))]";
  }

  return "metric-card--up bg-[radial-gradient(circle_at_82%_82%,rgba(21,240,168,0.08),transparent_24%),linear-gradient(180deg,rgba(17,39,61,0.96),rgba(8,18,32,0.98))]";
}

function deltaClass(tone) {
  return tone === "down" ? "text-red-400" : "text-emerald-300";
}

function deltaArrow(tone) {
  return tone === "down" ? "▼" : "▲";
}

function cardValueClass(card) {
  if (card.kind === "callout") {
    return "max-w-[calc(100%-4.9rem)] text-[1.5rem] leading-[1.02] tracking-[-0.03em]";
  }

  if (card.compact || card.value.length > 7) {
    return "text-[1.8rem] min-[500px]:text-[2.05rem]";
  }

  return "text-[1.95rem] min-[500px]:text-[2.28rem]";
}

function sparkline(points, tone) {
  const width = 220;
  const height = 82;
  const padding = 6;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const scale = max - min || 1;
  const color = tone === "down" ? "#ff2831" : "#15f0a8";

  const mappedPairs = points.map((point, index) => {
    const x = padding + (index * (width - padding * 2)) / (points.length - 1);
    const y = height - padding - ((point - min) * (height - padding * 2)) / scale;
    return [x, y];
  });

  const mapped = mappedPairs.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const [endX, endY] = mappedPairs[mappedPairs.length - 1];
  const area = `${mapped} ${width - padding},${height - padding} ${padding},${height - padding}`;
  const gradientId = `area-${tone}-${sparklineCounter++}`;

  return `
    <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true" class="h-full w-full overflow-visible">
      <defs>
        <linearGradient id="${gradientId}" x1="0%" x2="100%" y1="0%" y2="100%">
          <stop offset="0%" stop-color="${color}" stop-opacity="0.45"></stop>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"></stop>
        </linearGradient>
      </defs>
      <polyline class="sparkline-area" points="${area}" fill="url(#${gradientId})"></polyline>
      <polyline class="sparkline-line" points="${mapped}" style="color:${color}; stroke:${color};" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></polyline>
      <circle class="sparkline-end" cx="${endX.toFixed(1)}" cy="${endY.toFixed(1)}" r="4.6" fill="${color}" opacity="0.96"></circle>
    </svg>
  `;
}

function icon(name, className = "h-full w-full object-contain") {
  if (IMAGE_ASSETS[name]) {
    return `<img src="${IMAGE_ASSETS[name]}" alt="" class="${className}" loading="lazy" decoding="async">`;
  }

  if (name === "copper") {
    return `
      <svg viewBox="0 0 120 88" fill="none" aria-hidden="true">
        <rect x="24" y="44" width="42" height="14" rx="5" fill="#cc8657"/>
        <rect x="40" y="28" width="42" height="14" rx="5" fill="#e3a173"/>
        <rect x="56" y="44" width="42" height="14" rx="5" fill="#b96e3e"/>
        <rect x="48" y="58" width="42" height="14" rx="5" fill="#db9a6e"/>
      </svg>
    `;
  }

  return "";
}

function mountTickers() {
  const root = document.getElementById("ticker-board");
  root.innerHTML = tickerRows
    .map(
      (row) => `
        <div class="grid grid-cols-2 gap-px md:grid-cols-4">
          ${row
            .map(
              (item) => `
                <article class="min-w-0 bg-[radial-gradient(circle_at_50%_0%,rgba(64,99,188,0.11),transparent_52%),linear-gradient(180deg,rgba(12,25,48,0.98),rgba(7,15,27,0.98))] px-2 py-2 sm:px-2.5">
                  <div class="flex min-w-0 items-center gap-1.5 text-[8px] uppercase tracking-[0.08em] text-slate-200 sm:text-[9px]">
                    ${regionIcon(item.region)}
                    <span class="rounded-full border border-white/10 ${item.flag === "us" ? "bg-blue-500/20 text-blue-50" : "bg-amber-300/15 text-amber-50"} px-1.5 py-0.5">${item.region}</span>
                    <span class="truncate font-medium tracking-[0.02em] text-slate-100">${item.name}</span>
                  </div>
                  <div class="mt-1.5 flex items-baseline justify-between gap-2 text-[11px] sm:text-[12px]">
                    <span class="js-ticker-value whitespace-nowrap text-slate-300">${item.value}</span>
                    <span class="js-ticker-delta whitespace-nowrap font-semibold ${item.tone === "down" ? "text-red-400" : "text-emerald-300"}">${item.delta}</span>
                  </div>
                </article>
              `,
            )
            .join("")}
        </div>
      `,
    )
    .join("");
}

function renderMeta(card) {
  if (!card.delta && !card.foot) {
    return "";
  }

  const tone = card.tone === "down" ? "down" : "up";

  return `
    <div class="relative z-10 mt-2 inline-flex w-fit items-center gap-2 rounded-md bg-slate-400/10 px-2 py-1 text-[11px] font-semibold text-slate-50 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
      ${
        card.delta
          ? `<span class="${deltaClass(tone)} inline-flex items-center gap-1"><span class="text-[9px]">${deltaArrow(tone)}</span>${card.delta}</span>`
          : ""
      }
      ${card.foot ? `<span class="text-white/85">${card.foot}</span>` : ""}
    </div>
  `;
}

function renderSparkCard(card) {
  const tone = card.tone === "down" ? "down" : "up";
  const flag = flagMarkup(card.flag);
  const sparkClass = card.compact ? "h-12 pt-2" : "h-16 pt-2";
  const valueClass = cardValueClass(card);

  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone)} ${card.classes || ""}">
      <div class="relative z-10 flex items-center gap-2">
        ${flag}
        <span class="text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</span>
      </div>
      <div class="relative z-10 mt-1 whitespace-nowrap font-display font-semibold leading-[0.92] tracking-[-0.06em] text-white ${valueClass}">${card.value}</div>
      ${card.subtitle ? `<div class="relative z-10 mt-1 text-[10px] leading-[1.25] text-slate-400">${card.subtitle}</div>` : ""}
      ${renderMeta(card)}
      <div class="relative z-10 mt-auto ${sparkClass}">${sparkline(card.points, tone)}</div>
    </article>
  `;
}

function renderBreadthCard(card) {
  return `
    <article class="${CARD_BASE} ${toneBackground("up")}">
      <div class="relative z-10 text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</div>
      <div class="relative z-10 mt-2 grid grid-cols-2 gap-x-2 gap-y-1">
        <div class="min-w-0">
          <div class="text-[2rem] font-semibold leading-[0.9] tracking-[-0.06em] text-emerald-300">${card.advancing}</div>
          <div class="mt-0.5 text-[11px] text-slate-200">Advancing</div>
        </div>
        <div class="min-w-0 text-right">
          <div class="text-[2rem] font-semibold leading-[0.9] tracking-[-0.06em] text-red-400">${card.declining}</div>
          <div class="mt-0.5 text-[11px] text-slate-200">Declining</div>
        </div>
        <div class="col-span-2 mt-1 h-2 overflow-hidden rounded-full bg-[linear-gradient(90deg,rgba(34,235,163,0.26),rgba(255,40,49,0.22))]">
          <div class="h-full w-[67%] bg-[linear-gradient(90deg,rgba(30,215,160,0.96),rgba(64,247,187,0.68))]"></div>
        </div>
        <div class="col-span-2 mt-1 flex items-center justify-between text-[11px] font-medium text-slate-50">
          <span>A/D Ratio</span>
          <strong>${card.ratio}</strong>
        </div>
      </div>
    </article>
  `;
}

function renderCalloutCard(card) {
  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone, "callout")} ${card.classes || ""}">
      <div class="relative z-10 text-[11px] font-medium uppercase tracking-[0.02em] text-slate-200">${card.title}</div>
      <div class="relative z-10 mt-1 max-w-[calc(100%-4rem)] font-display font-semibold text-white ${cardValueClass(card)}">${card.value}</div>
      ${renderMeta(card)}
      <div class="absolute z-10 opacity-[0.98] drop-shadow-[0_12px_18px_rgba(0,0,0,0.35)] ${card.mediaWrapClass || "bottom-0 right-0 h-[4.7rem] w-[6rem]"}">
        ${icon(card.illustration, card.mediaClass)}
      </div>
    </article>
  `;
}

function renderStatCard(card) {
  const flag = flagMarkup(card.flag);
  const valueClass = cardValueClass(card);

  return `
    <article class="${CARD_BASE} ${toneBackground(card.tone)} ${card.classes || ""}">
      <div class="relative z-10 flex items-center gap-2">
        ${flag}
        <span class="text-[11px] font-medium uppercase tracking-[0.02em] text-slate-300">${card.title}</span>
      </div>
      <div class="relative z-10 mt-1 whitespace-nowrap font-display font-semibold leading-[0.92] tracking-[-0.06em] text-white ${valueClass}">${card.value}</div>
      ${card.subtitle ? `<div class="relative z-10 mt-1 text-[10px] leading-[1.25] text-slate-400">${card.subtitle}</div>` : ""}
      ${renderMeta(card)}
      ${
        card.illustration
          ? `<div class="absolute z-10 opacity-[0.98] drop-shadow-[0_12px_18px_rgba(0,0,0,0.35)] ${card.mediaWrapClass || "bottom-0 right-0 h-[4.5rem] w-[5.8rem]"}">${icon(card.illustration, card.mediaClass)}</div>`
          : ""
      }
    </article>
  `;
}

function renderCards(cards, rootId) {
  const root = document.getElementById(rootId);
  root.innerHTML = cards
    .map((card) => {
      if (card.kind === "spark") return renderSparkCard(card);
      if (card.kind === "breadth") return renderBreadthCard(card);
      if (card.kind === "callout") return renderCalloutCard(card);
      return renderStatCard(card);
    })
    .join("");
}

function animateTickers() {
  const tickerValues = [...document.querySelectorAll(".js-ticker-value")];
  const tickerDeltas = [...document.querySelectorAll(".js-ticker-delta")];

  window.setInterval(() => {
    tickerValues.forEach((node, index) => {
      const raw = Number(node.textContent.replace(/,/g, ""));
      const drift = (Math.random() - 0.5) * (index % 2 === 0 ? 18 : 32);
      const next = Math.max(raw + drift, 1000);
      node.textContent = next.toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    });

    tickerDeltas.forEach((node) => {
      const positive = Math.random() > 0.33;
      const delta = (Math.random() * 1.5 + 0.05).toFixed(2);
      node.textContent = `${positive ? "+" : "-"}${delta}%`;
      node.classList.toggle("text-emerald-300", positive);
      node.classList.toggle("text-red-400", !positive);
    });
  }, 3200);
}

mountTickers();
renderCards(marketCards, "market-grid");
renderCards(economicCards, "economic-grid");
renderCards(commodityCards, "commodity-grid");
animateTickers();
