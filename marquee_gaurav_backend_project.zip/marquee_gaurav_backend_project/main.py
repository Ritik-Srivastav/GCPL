from fastapi import FastAPI, Depends, HTTPException, status
import secrets
import os
from dotenv import load_dotenv
from database import engine, Base

load_dotenv()


import apis.all_indices as all_indices
import apis.world_indices as world_indices
from fastapi.middleware.cors import CORSMiddleware

# Create Database Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="live Dashboard", description="Live NSE Market Data")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Your Vite dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount routers with authentication dependency

app.include_router(all_indices.router, prefix="/api")
app.include_router(world_indices.router, prefix="/api")



@app.get("/")
def home():
    return {"message": "Welcome. Go to /docs for Swagger UI"}
