from sqlalchemy import Column, String, DateTime, Float
from datetime import datetime
from zoneinfo import ZoneInfo
from database import Base

IST = ZoneInfo("Asia/Kolkata")

class ScrapedData(Base):
    __tablename__ = "scraped_data"

    data_key = Column(String, primary_key=True, index=True)
    payload = Column(String, nullable=False)
    last_updated = Column(
        DateTime,
        default=lambda: datetime.now(IST),
        onupdate=lambda: datetime.now(IST)
    )
